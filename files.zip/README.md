# 🚀 تستر کانفیگ VPN

<div align="center">

![GitHub stars](https://img.shields.io/github/stars/yourusername/vpn-config-tester?style=social)
![GitHub forks](https://img.shields.io/github/forks/yourusername/vpn-config-tester?style=social)
![GitHub issues](https://img.shields.io/github/issues/yourusername/vpn-config-tester)
![GitHub license](https://img.shields.io/github/license/yourusername/vpn-config-tester)
![Node.js Version](https://img.shields.io/badge/node-%3E%3D16-brightgreen)

یک وب‌اپلیکیشن قدرتمند برای تست کانفیگ‌های VPN با اندازه‌گیری سرعت و پینگ واقعی

[دمو](#-دمو) • [ویژگی‌ها](#-ویژگیها) • [نصب](#️-نصب-و-راهاندازی) • [استفاده](#-نحوه-استفاده) • [API](#-api-endpoints) • [مشارکت](#-مشارکت)

</div>

---

## 📸 تصاویر

<div align="center">
  <img src="https://via.placeholder.com/800x400/0a0e27/00d9ff?text=VPN+Config+Tester+Dashboard" alt="Dashboard Screenshot" width="100%">
</div>

## ✨ ویژگی‌ها

### 🔌 پروتکل‌های پشتیبانی شده

- ✅ **VMess** - پروتکل V2Ray
- ✅ **VLESS** - نسل جدید V2Ray
- ✅ **Shadowsocks** - پروتکل محبوب و سریع
- ✅ **Trojan** - پروتکل امن و مخفی

### 📊 امکانات تست

- ⚡ **تست سرعت دانلود و آپلود** - اندازه‌گیری دقیق سرعت
- 🏓 **اندازه‌گیری پینگ** - زمان پاسخ سرور
- ⏱️ **محاسبه Latency** - تاخیر اتصال
- 📈 **اندازه‌گیری Jitter** - نوسان پینگ
- 🌐 **نمایش IP کاربر** - شناسایی خودکار IP

### 🎨 رابط کاربری

- 🌙 **Dark Mode** زیبا با تم نئونی
- 📱 **Responsive Design** - سازگار با موبایل و تبلت
- ✨ **انیمیشن‌های Smooth** - تجربه کاربری عالی
- 📊 **نمایش آمار** - داشبورد جامع نتایج
- 🔄 **Real-time Updates** - به‌روزرسانی لحظه‌ای

### ⚙️ قابلیت‌های پیشرفته

- 📥 **دریافت از URL** - fetch خودکار کانفیگ‌ها
- 📝 **ورود دستی** - paste کانفیگ‌های خود
- 🔢 **تست Batch** - تست همزمان چندین کانفیگ
- 💾 **API RESTful** - یکپارچه‌سازی آسان
- 🐳 **Docker Support** - استقرار راحت

## 🛠️ نصب و راه‌اندازی

### پیش‌نیازها

- **Node.js** >= 16.0.0
- **npm** یا **yarn**

### نصب سریع

```bash
# کلون کردن پروژه
git clone https://github.com/yourusername/vpn-config-tester.git
cd vpn-config-tester

# نصب وابستگی‌ها
npm install

# اجرای سرور
npm start
```

سرور روی `http://localhost:3000` اجرا می‌شود.

### استفاده از Docker

```bash
# Build و اجرا با Docker Compose
docker-compose up -d

# یا با Docker مستقیم
docker build -t vpn-tester .
docker run -p 3000:3000 vpn-tester
```

### استفاده از Standalone Version

برای استفاده بدون سرور، فایل `vpn-tester.html` را در مرورگر باز کنید.

## 📖 نحوه استفاده

### روش اول: دریافت از URL

1. URL منبع کانفیگ‌های خود را وارد کنید
2. دکمه **"شروع تست"** را بزنید
3. منتظر نتایج بمانید

```
https://example.com/configs.txt
```

### روش دوم: ورود دستی

1. کانفیگ‌های خود را paste کنید (هر کانفیگ در یک خط)
2. دکمه **"شروع تست"** را بزنید

### فرمت‌های پشتیبانی شده

```text
# VMess
vmess://eyJhZGQiOiIxMjcuMC4wLjEiLCJwb3J0IjoiNDQzIi4uLn0=

# VLESS
vless://uuid@server:port?type=tcp&security=tls#ConfigName

# Shadowsocks
ss://method:password@server:port#ConfigName

# Trojan
trojan://password@server:port?sni=domain#ConfigName
```

## 🔌 API Endpoints

### تست تک کانفیگ

```http
POST /api/test-config
Content-Type: application/json

{
  "config": "vmess://..."
}
```

**پاسخ:**

```json
{
  "status": "success",
  "config": {
    "type": "vmess",
    "server": "example.com",
    "port": 443,
    "name": "Config Name"
  },
  "results": {
    "ping": 45,
    "latency": 43,
    "downloadSpeed": 35.5,
    "uploadSpeed": 15.2,
    "jitter": 3
  },
  "userIp": "1.2.3.4",
  "timestamp": "2025-02-05T08:00:00.000Z"
}
```

### تست دسته‌ای

```http
POST /api/test-batch
Content-Type: application/json

{
  "configs": [
    "vmess://...",
    "vless://...",
    "ss://..."
  ]
}
```

### دریافت کانفیگ از URL

```http
POST /api/fetch-configs
Content-Type: application/json

{
  "url": "https://example.com/configs.txt"
}
```

### دریافت IP کاربر

```http
GET /api/my-ip
```

**پاسخ:**

```json
{
  "ip": "1.2.3.4"
}
```

## 📊 پارامترهای اندازه‌گیری

| پارامتر | واحد | توضیحات |
|---------|------|---------|
| **Ping** | ms | زمان پاسخ سرور |
| **Latency** | ms | تاخیر اتصال |
| **Download Speed** | Mbps | سرعت دانلود |
| **Upload Speed** | Mbps | سرعت آپلود |
| **Jitter** | ms | نوسان پینگ |

### معیارهای ارزیابی

#### پینگ (Ping)
- 🟢 **عالی**: < 50ms
- 🟡 **متوسط**: 50-150ms
- 🔴 **ضعیف**: > 150ms

#### سرعت دانلود
- 🟢 **عالی**: > 30 Mbps
- 🟡 **متوسط**: 15-30 Mbps
- 🔴 **ضعیف**: < 15 Mbps

## 🎨 تکنولوژی‌ها

### Frontend
- **HTML5** - ساختار صفحات
- **CSS3** - استایل‌دهی پیشرفته
- **JavaScript (ES6+)** - منطق برنامه
- **Fetch API** - ارتباط با backend

### Backend
- **Node.js** - محیط اجرای JavaScript
- **Express.js** - فریمورک وب
- **Axios** - HTTP client
- **Net Module** - تست اتصال TCP

### DevOps
- **Docker** - containerization
- **GitHub Actions** - CI/CD
- **ESLint** - code quality

## ⚙️ تنظیمات پیشرفته

### تغییر پورت

در فایل `.env`:

```env
PORT=3000
```

یا در `server.js`:

```javascript
const PORT = process.env.PORT || 3000;
```

### تنظیم Timeout

```javascript
const connectionTest = await testTCPConnection(
  parsed.server, 
  parsed.port, 
  5000 // timeout (ms)
);
```

### استقرار در Production

#### با Nginx

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
```

#### با PM2

```bash
npm install -g pm2
pm2 start server.js --name vpn-tester
pm2 save
pm2 startup
```

## 🔒 امنیت

- ✅ Input validation
- ✅ CORS configuration
- ✅ Rate limiting
- ✅ Error handling
- ✅ No sensitive data logging

برای گزارش مشکلات امنیتی، لطفاً [SECURITY.md](SECURITY.md) را مطالعه کنید.

## 🐛 عیب‌یابی

### خطای "ECONNREFUSED"

```bash
# بررسی کنید سرور اجرا شده باشد
lsof -i :3000

# راه‌اندازی مجدد
npm start
```

### خطای "Invalid config format"

- فرمت کانفیگ را بررسی کنید
- از base64 encoding صحیح اطمینان حاصل کنید

### نتایج نادرست

- اتصال اینترنت را چک کنید
- Firewall را بررسی کنید
- Proxy settings را کنترل کنید

## 🤝 مشارکت

مشارکت‌های شما با آغوش باز پذیرفته می‌شود! لطفاً [CONTRIBUTING.md](CONTRIBUTING.md) را مطالعه کنید.

### راه‌های مشارکت:

- 🐛 گزارش باگ
- 💡 پیشنهاد ویژگی جدید
- 📝 بهبود مستندات
- 🔧 ارسال Pull Request
- ⭐ ستاره دادن به پروژه

## 📝 لایسنس

این پروژه تحت لایسنس [MIT](LICENSE) منتشر شده است.

## 🙏 قدردانی

از تمام مشارکت‌کنندگانی که به بهبود این پروژه کمک کرده‌اند، تشکر می‌کنیم!

## 📧 تماس

- **Issues**: [GitHub Issues](https://github.com/yourusername/vpn-config-tester/issues)
- **Discussions**: [GitHub Discussions](https://github.com/yourusername/vpn-config-tester/discussions)

## ⭐ ستاره‌دهی

اگر این پروژه برای شما مفید بود، لطفاً یک ستاره ⭐ بدهید!

---

<div align="center">

**ساخته شده با ❤️ برای جامعه VPN**

[به بالا برگرد](#-تستر-کانفیگ-vpn)

</div>
