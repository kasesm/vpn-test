# 🚀 راهنمای سریع شروع

## برای گیتهاب

### 1️⃣ ایجاد مخزن جدید

```bash
# در گیتهاب یک repository جدید بسازید (مثلاً vpn-config-tester)
# سپس دستورات زیر را اجرا کنید:

cd vpn-config-tester
git init
git add .
git commit -m "Initial commit: VPN Config Tester v1.0.0"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/vpn-config-tester.git
git push -u origin main
```

### 2️⃣ تنظیمات گیتهاب

#### فعال کردن GitHub Actions

1. به تب **Actions** در repository خود بروید
2. GitHub Actions را فعال کنید

#### تنظیم Docker Hub (اختیاری)

اگر می‌خواهید Docker image خودکار build شود:

1. به **Settings** > **Secrets and variables** > **Actions** بروید
2. سه secret اضافه کنید:
   - `DOCKER_USERNAME`: username Docker Hub شما
   - `DOCKER_PASSWORD`: password Docker Hub شما

#### فعال کردن GitHub Pages (اختیاری)

برای دمو آنلاین:

1. به **Settings** > **Pages** بروید
2. Source را روی **GitHub Actions** بگذارید
3. فایل `vpn-tester.html` را به عنوان index.html معرفی کنید

## نصب و اجرای محلی

### روش 1: استاندارد

```bash
# کلون کردن
git clone https://github.com/YOUR_USERNAME/vpn-config-tester.git
cd vpn-config-tester

# نصب
npm install

# اجرا
npm start
```

### روش 2: با Docker

```bash
# کلون کردن
git clone https://github.com/YOUR_USERNAME/vpn-config-tester.git
cd vpn-config-tester

# اجرا با Docker Compose
docker-compose up -d

# مشاهده logs
docker-compose logs -f

# توقف
docker-compose down
```

### روش 3: استفاده سریع (بدون نصب)

فقط فایل `vpn-tester.html` را در مرورگر باز کنید!

## تست سریع

پس از اجرا، به آدرس زیر بروید:

```
http://localhost:3000
```

یک کانفیگ تست وارد کنید:

```
vmess://eyJhZGQiOiIxMjcuMC4wLjEiLCJwb3J0IjoiNDQzIiwidHlwZSI6Im5vbmUiLCJpZCI6IjEyMzQ1Njc4LTEyMzQtMTIzNC0xMjM0LTEyMzQ1Njc4OTAxMiIsImFpZCI6IjAiLCJuZXQiOiJ0Y3AiLCJwcyI6IlRlc3QifQ==
```

## دستورات مفید

```bash
# نصب وابستگی‌ها
npm install

# اجرای سرور
npm start

# اجرای سرور در حالت development (با auto-reload)
npm run dev

# Build Docker image
docker build -t vpn-tester .

# اجرای Docker container
docker run -p 3000:3000 vpn-tester

# اجرا با Docker Compose
docker-compose up -d

# مشاهده logs
docker-compose logs -f

# توقف Docker
docker-compose down

# بررسی وضعیت سرویس
curl http://localhost:3000/api/my-ip
```

## مشکلات رایج و راه‌حل

### خطا: Port 3000 is already in use

```bash
# یافتن process
lsof -i :3000

# کشتن process
kill -9 PID
```

### خطا: Cannot find module

```bash
# پاک کردن و نصب مجدد
rm -rf node_modules package-lock.json
npm install
```

### خطا: Permission denied (Docker)

```bash
# افزودن user به گروه docker
sudo usermod -aG docker $USER

# خروج و ورود مجدد برای اعمال تغییرات
```

## بعد از آپلود به گیتهاب

1. ✅ README را بخوانید و مطمئن شوید که همه چیز درسته
2. ✅ badge های GitHub را در README به‌روزرسانی کنید (username خود را جایگزین کنید)
3. ✅ یک Release ایجاد کنید (v1.0.0)
4. ✅ Topics مناسب اضافه کنید: `vpn`, `tester`, `nodejs`, `express`, `docker`
5. ✅ Description مخزن را تنظیم کنید
6. ✅ یک screenshot از UI بگیرید و در README اضافه کنید
7. ✅ LICENSE را بررسی کنید
8. ✅ در صورت تمایل، GitHub Pages را فعال کنید

## چک‌لیست قبل از انتشار

- [ ] تمام فایل‌ها commit شده‌اند
- [ ] README کامل و واضح است
- [ ] LICENSE موجود است
- [ ] .gitignore صحیح است
- [ ] package.json به‌روز است
- [ ] مستندات کامل است
- [ ] نمونه‌های استفاده موجود است
- [ ] دستورات نصب تست شده‌اند
- [ ] CI/CD تنظیم شده است (اختیاری)

## بروزرسانی‌های آینده

برای اضافه کردن ویژگی‌های جدید:

```bash
# ایجاد branch جدید
git checkout -b feature/new-feature

# تغییرات
# ...

# commit
git add .
git commit -m "Add: ویژگی جدید"

# push
git push origin feature/new-feature

# سپس Pull Request باز کنید
```

## کمک و پشتیبانی

- 📖 [README کامل](README.md)
- 🤝 [راهنمای مشارکت](CONTRIBUTING.md)
- 🔒 [امنیت](SECURITY.md)
- 📋 [ساختار پروژه](STRUCTURE.md)

## لینک‌های مفید

- [GitHub: ساخت Repository](https://docs.github.com/en/get-started/quickstart/create-a-repo)
- [GitHub Actions](https://docs.github.com/en/actions)
- [Docker Hub](https://hub.docker.com/)
- [npm Documentation](https://docs.npmjs.com/)

---

**موفق باشید! 🎉**
