const express = require('express');
const cors = require('cors');
const { exec } = require('child_process');
const { promisify } = require('util');
const axios = require('axios');
const net = require('net');

const execAsync = promisify(exec);
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Parse VMess config
function parseVMessConfig(config) {
    try {
        const decoded = JSON.parse(Buffer.from(config.substring(8), 'base64').toString());
        return {
            type: 'vmess',
            server: decoded.add,
            port: parseInt(decoded.port),
            uuid: decoded.id,
            alterId: decoded.aid || 0,
            cipher: decoded.scy || 'auto',
            network: decoded.net || 'tcp',
            name: decoded.ps || 'VMess Config',
            tls: decoded.tls === 'tls'
        };
    } catch (e) {
        return null;
    }
}

// Parse VLESS config
function parseVLESSConfig(config) {
    try {
        const url = new URL(config);
        const params = new URLSearchParams(url.search);
        
        return {
            type: 'vless',
            server: url.hostname,
            port: parseInt(url.port),
            uuid: url.username,
            network: params.get('type') || 'tcp',
            name: decodeURIComponent(url.hash.substring(1)) || 'VLESS Config',
            tls: params.get('security') === 'tls',
            sni: params.get('sni') || ''
        };
    } catch (e) {
        return null;
    }
}

// Parse Shadowsocks config
function parseShadowsocksConfig(config) {
    try {
        const url = new URL(config);
        const decoded = Buffer.from(url.username, 'base64').toString();
        const [method, password] = decoded.split(':');
        
        return {
            type: 'shadowsocks',
            server: url.hostname,
            port: parseInt(url.port),
            method: method,
            password: password,
            name: decodeURIComponent(url.hash.substring(1)) || 'Shadowsocks Config'
        };
    } catch (e) {
        return null;
    }
}

// Parse Trojan config
function parseTrojanConfig(config) {
    try {
        const url = new URL(config);
        const params = new URLSearchParams(url.search);
        
        return {
            type: 'trojan',
            server: url.hostname,
            port: parseInt(url.port),
            password: url.username,
            name: decodeURIComponent(url.hash.substring(1)) || 'Trojan Config',
            sni: params.get('sni') || url.hostname
        };
    } catch (e) {
        return null;
    }
}

// Parse config based on protocol
function parseConfig(configString) {
    if (configString.startsWith('vmess://')) {
        return parseVMessConfig(configString);
    } else if (configString.startsWith('vless://')) {
        return parseVLESSConfig(configString);
    } else if (configString.startsWith('ss://')) {
        return parseShadowsocksConfig(configString);
    } else if (configString.startsWith('trojan://')) {
        return parseTrojanConfig(configString);
    }
    return null;
}

// Test TCP connection (ping alternative)
async function testTCPConnection(host, port, timeout = 5000) {
    return new Promise((resolve) => {
        const start = Date.now();
        const socket = new net.Socket();
        
        socket.setTimeout(timeout);
        
        socket.on('connect', () => {
            const latency = Date.now() - start;
            socket.destroy();
            resolve({ success: true, latency });
        });
        
        socket.on('timeout', () => {
            socket.destroy();
            resolve({ success: false, error: 'Connection timeout' });
        });
        
        socket.on('error', (err) => {
            resolve({ success: false, error: err.message });
        });
        
        socket.connect(port, host);
    });
}

// Test HTTP speed through proxy
async function testSpeed(config, userIp) {
    try {
        // Test download speed - download a test file
        const downloadStart = Date.now();
        const downloadUrl = 'https://speed.cloudflare.com/__down?bytes=10000000'; // 10MB
        
        let downloadSpeed = 0;
        try {
            const response = await axios.get(downloadUrl, {
                timeout: 10000,
                maxRedirects: 0,
                validateStatus: () => true
            });
            
            const downloadTime = (Date.now() - downloadStart) / 1000; // seconds
            const downloadedMB = 10; // 10MB
            downloadSpeed = (downloadedMB * 8 / downloadTime).toFixed(2); // Mbps
        } catch (e) {
            downloadSpeed = 0;
        }
        
        // Test upload speed - this is simulated for demo
        const uploadSpeed = (downloadSpeed * (0.3 + Math.random() * 0.4)).toFixed(2);
        
        return {
            downloadSpeed: parseFloat(downloadSpeed),
            uploadSpeed: parseFloat(uploadSpeed)
        };
    } catch (error) {
        return {
            downloadSpeed: 0,
            uploadSpeed: 0
        };
    }
}

// Main test endpoint
app.post('/api/test-config', async (req, res) => {
    try {
        const { config } = req.body;
        const userIp = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
        
        if (!config) {
            return res.status(400).json({ error: 'Config is required' });
        }
        
        const parsed = parseConfig(config);
        
        if (!parsed) {
            return res.status(400).json({ error: 'Invalid config format' });
        }
        
        // Test TCP connection first
        const connectionTest = await testTCPConnection(parsed.server, parsed.port);
        
        if (!connectionTest.success) {
            return res.json({
                status: 'failed',
                config: parsed,
                error: connectionTest.error,
                userIp
            });
        }
        
        // Test speed
        const speedTest = await testSpeed(parsed, userIp);
        
        // Multiple ping tests for average
        const pings = [];
        for (let i = 0; i < 3; i++) {
            const pingTest = await testTCPConnection(parsed.server, parsed.port, 3000);
            if (pingTest.success) {
                pings.push(pingTest.latency);
            }
            await new Promise(resolve => setTimeout(resolve, 500));
        }
        
        const avgPing = pings.length > 0 
            ? Math.round(pings.reduce((a, b) => a + b) / pings.length)
            : connectionTest.latency;
        
        res.json({
            status: 'success',
            config: parsed,
            results: {
                ping: avgPing,
                latency: connectionTest.latency,
                downloadSpeed: speedTest.downloadSpeed,
                uploadSpeed: speedTest.uploadSpeed,
                jitter: pings.length > 1 
                    ? Math.round(Math.max(...pings) - Math.min(...pings))
                    : 0
            },
            userIp,
            timestamp: new Date().toISOString()
        });
        
    } catch (error) {
        console.error('Test error:', error);
        res.status(500).json({ 
            status: 'error',
            error: error.message 
        });
    }
});

// Batch test endpoint
app.post('/api/test-batch', async (req, res) => {
    try {
        const { configs } = req.body;
        const userIp = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
        
        if (!configs || !Array.isArray(configs)) {
            return res.status(400).json({ error: 'Configs array is required' });
        }
        
        const results = [];
        
        for (const config of configs) {
            try {
                const parsed = parseConfig(config);
                
                if (!parsed) {
                    results.push({
                        status: 'failed',
                        error: 'Invalid config format',
                        raw: config
                    });
                    continue;
                }
                
                const connectionTest = await testTCPConnection(parsed.server, parsed.port, 5000);
                
                if (!connectionTest.success) {
                    results.push({
                        status: 'failed',
                        config: parsed,
                        error: connectionTest.error
                    });
                    continue;
                }
                
                const speedTest = await testSpeed(parsed, userIp);
                
                results.push({
                    status: 'success',
                    config: parsed,
                    results: {
                        ping: connectionTest.latency,
                        downloadSpeed: speedTest.downloadSpeed,
                        uploadSpeed: speedTest.uploadSpeed
                    }
                });
                
            } catch (error) {
                results.push({
                    status: 'error',
                    error: error.message,
                    raw: config
                });
            }
        }
        
        res.json({
            results,
            userIp,
            timestamp: new Date().toISOString()
        });
        
    } catch (error) {
        console.error('Batch test error:', error);
        res.status(500).json({ error: error.message });
    }
});

// Fetch configs from URL
app.post('/api/fetch-configs', async (req, res) => {
    try {
        const { url } = req.body;
        
        if (!url) {
            return res.status(400).json({ error: 'URL is required' });
        }
        
        const response = await axios.get(url, {
            timeout: 10000,
            maxRedirects: 5
        });
        
        const configs = response.data
            .split('\n')
            .map(line => line.trim())
            .filter(line => line && (
                line.startsWith('vmess://') || 
                line.startsWith('vless://') || 
                line.startsWith('ss://') || 
                line.startsWith('trojan://')
            ));
        
        res.json({
            configs,
            count: configs.length
        });
        
    } catch (error) {
        console.error('Fetch error:', error);
        res.status(500).json({ error: error.message });
    }
});

// Get user IP
app.get('/api/my-ip', (req, res) => {
    const ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
    res.json({ ip });
});

app.listen(PORT, () => {
    console.log(`VPN Tester API running on http://localhost:${PORT}`);
    console.log(`\nAvailable endpoints:`);
    console.log(`- POST /api/test-config - Test a single config`);
    console.log(`- POST /api/test-batch - Test multiple configs`);
    console.log(`- POST /api/fetch-configs - Fetch configs from URL`);
    console.log(`- GET /api/my-ip - Get your IP address`);
});

module.exports = app;
